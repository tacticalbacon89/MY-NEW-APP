#include "ConfigGlobals.h"
using namespace std;


WindowConfig G_WindowConfig;